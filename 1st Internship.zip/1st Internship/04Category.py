import pymysql

con=pymysql.connect(host="bkapjllbob5kfxuy2caj-mysql.services.clever-cloud.com",user="up0aqh16jfalyett",password="BXHBu6SgcHEoU4ynJIX2",database="bkapjllbob5kfxuy2caj")
curs=con.cursor()
ct=input("Enter a Category:")
curs.execute("select * from books where Category='%s'"%ct)
data=curs.fetchall()
for rec in data:
    print(rec[1])

con.close()

