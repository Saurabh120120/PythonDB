import pymysql

con=pymysql.connect(host="bkapjllbob5kfxuy2caj-mysql.services.clever-cloud.com",user="up0aqh16jfalyett",password="BXHBu6SgcHEoU4ynJIX2",database="bkapjllbob5kfxuy2caj")
curs=con.cursor()
try:
    
    cd=int(input("Enter Book Code:"))    
    curs.execute("select * from books where bookcode=%d"%(cd))  
    data=curs.fetchall()
    
    print(data)
    
    if data:
        nw=float(input("Enter New Price:"))
        curs.execute("update books set price=%.2f where bookcode=%d"%(nw,cd))
        con.commit()
        print("Price Updated")
    else:
        print("Book Does Not Exist")
    
except Exception as e:
    print("Error",e)

con.close()
