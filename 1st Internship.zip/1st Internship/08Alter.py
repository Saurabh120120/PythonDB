import pymysql

con=pymysql.connect(host='bkapjllbob5kfxuy2caj-mysql.services.clever-cloud.com',user='up0aqh16jfalyett',password='BXHBu6SgcHEoU4ynJIX2',database='bkapjllbob5kfxuy2caj')
try:
    curs=con.cursor()
    curs.execute("alter table books add review varchar(500)")
    con.commit()
    print("New Column Added")
except Exception as e:
    print("Error",e)
finally:
    con.close()

