import pymysql
con=pymysql.connect(host='bkapjllbob5kfxuy2caj-mysql.services.clever-cloud.com',user='up0aqh16jfalyett',password='BXHBu6SgcHEoU4ynJIX2',database='bkapjllbob5kfxuy2caj')
curs=con.cursor()
try:
    cd=int(input("Enter Book Code:"))
    nm=input("Enter Book Name:")
    ct=input("Enter Category:")
    at=input("Enter Author Name:")
    pb=input("Enter Publication:")
    ed=int(input("Enter Edition:"))
    pr=float(input("Enter Price:"))

    curs.execute("insert into books values(%d,'%s','%s','%s','%s',%d,%.2f)" %(cd,nm,ct,at,pb,ed,pr))
    con.commit()

    
except Exception as e:
    print("Error",e)

con.close()