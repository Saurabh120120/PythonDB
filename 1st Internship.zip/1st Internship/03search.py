import pymysql
con=pymysql.connect(host="bkapjllbob5kfxuy2caj-mysql.services.clever-cloud.com",user="up0aqh16jfalyett",password="BXHBu6SgcHEoU4ynJIX2",database="bkapjllbob5kfxuy2caj")
curs=con.cursor()
try:    
    cd=int(input("Enter Books Code:"))
    curs.execute("select * from books where bookcode=%d" %cd)
    data=curs.fetchone()
    if data:
        print(data)
    else:
        print("Book Not Found")
except Exception as e:

    print("Error ",e)
con.close()
