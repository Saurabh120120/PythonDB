import pymysql
con=pymysql.connect(host='bkapjllbob5kfxuy2caj-mysql.services.clever-cloud.com',user='up0aqh16jfalyett',password='BXHBu6SgcHEoU4ynJIX2',database='bkapjllbob5kfxuy2caj')
curs=con.cursor()

import pymysql
con=pymysql.connect(host='bkapjllbob5kfxuy2caj-mysql.services.clever-cloud.com',user='up0aqh16jfalyett',password='BXHBu6SgcHEoU4ynJIX2',database='bkapjllbob5kfxuy2caj')
curs=con.cursor()
try:
    curs.execute("select * from books")
    data=curs.fetchall()
    for rec in data:
        print(rec)
    
    
except Exception as e:
    print("Error",e)
con.close()
