import pymysql

con=pymysql.connect(host='bkapjllbob5kfxuy2caj-mysql.services.clever-cloud.com',user='up0aqh16jfalyett',password='BXHBu6SgcHEoU4ynJIX2',database='bkapjllbob5kfxuy2caj')

curs=con.cursor()
try:
    bc=int(input("Enter bookcode:"))
    rw=input("Write a Review:")
    curs.execute("select * from books where bookcode=%d"%bc)
    data=curs.fetchone()
    if data:
        curs.execute("update books set review='%s'"%rw)
        print("Review Added")
        con.commit()
    else:
        print("Book Does Not Exist")
except Exception as e:
    print("Error",e)

